import SearchSaved from '../conponents/SearchSaved';
import Header from '../conponents/Header';
function Save() {
    return (
        <main>
            <Header></Header>
            <SearchSaved></SearchSaved>
            <section className='row'></section>
        </main>


    )
};

export default Save;