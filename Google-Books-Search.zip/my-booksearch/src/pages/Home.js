import Header from '../conponents/Header';
import Search from '../conponents/Search';



function Home({props}) {
    
    return (
        <main>
            <Header></Header>
            <Search></Search>
            
            <section className='row'></section>
        </main>


    )
};

export default Home;